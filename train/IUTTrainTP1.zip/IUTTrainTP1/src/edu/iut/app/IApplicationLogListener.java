package edu.iut.app;

public interface IApplicationLogListener {
	/** TP1 : Créer la fuonction newMessage */
}
